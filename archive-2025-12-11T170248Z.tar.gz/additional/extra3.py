import aiohttp
import discord
from discord.ext import commands
import wavelink, json
import asyncio
from pystyle import Center, Colorate, Colors
import random
import requests
from datetime import datetime
import pytz

def time():
    timezone = pytz.timezone(time_zone)
    time = datetime.now(timezone)
    return time.strftime("%I:%M %p")

def load_config():
    with open('music_config.json', 'r') as f:
        return json.load(f)

def load_config2():
    with open('config.json', 'r') as f:
        return json.load(f)

config = load_config()
config2 = load_config2()
OWNER_ID = config['allowed_users']
music_token = config['token']

async def get_prefix(bot, message):
    config = load_config()
    return config.get("prefix", ",")

prefix = get_prefix
time_zone = config2['time_zone']
queues = {}
skipped_tracks = {}
player_text_channels = {}
loop_mode = {}
autoplay_mode = {}  # Autoplay OFF by default, user must enable it
guild_volumes = {}  # Store custom volumes per guild (persistent)
played_tracks = {}  # Track history to avoid repeats in autoplay

bot = commands.Bot(command_prefix=prefix, help_command=None)

@bot.event
async def on_ready():
    ascii_art = """
    ╔═══════════════════════════════════════════════════════════╗
    ║                                                           ║
    ║          🎵 MUSIC BOT ONLINE 🎵                          ║
    ║                                                           ║
    ║     Bot: {bot_name:<45}  ║
    ║     Prefix: {prefix:<43}  ║
    ║     Servers: {servers:<42}  ║
    ║                                                           ║
    ╚═══════════════════════════════════════════════════════════╝
    """
    
    bot_info = ascii_art.format(
        bot_name=bot.user.name,
        prefix=",",
        servers=len(bot.guilds)
    )
    
    print("\033[96m" + bot_info + "\033[0m")
    
    host = config["lavalink_host"]
    port = config["lavalink_port"]
    password = config["lavalink_password"]
    https = config["lavalink_https"]
    uri = f"https://{host}:{port}" if https else f"http://{host}:{port}"
    nodes = [wavelink.Node(uri=uri, password=password)]
    await wavelink.Pool.connect(nodes=nodes, client=bot, cache_capacity=100)
    print(f"\033[92m[LAVALINK]\033[0m ✅ Connected to {uri}")

@bot.event
async def on_wavelink_track_end(payload: wavelink.TrackEndEventPayload):
    """Handles what happens when a track ends"""
    player = payload.player
    if not player:
        return
    
    guild_id = player.guild.id
    
    # Apply guild volume
    guild_vol = get_volume(guild_id)
    if player.volume != guild_vol:
        await player.set_volume(guild_vol)
    
    # Check loop mode
    if loop_mode.get(guild_id, False):
        try:
            await player.play(payload.track)
            print(f"\033[95m[LOOP]\033[0m 🔁 {payload.track.title}")
        except Exception as e:
            print(f"\033[91m[ERROR]\033[0m Loop failed: {e}")
            loop_mode[guild_id] = False
        return
    
    # Play next track from queue (PRIORITY)
    if not player.queue.is_empty:
        try:
            next_track = await player.queue.get_wait()
            await player.play(next_track)
            
            # Send now playing message
            try:
                if guild_id in player_text_channels:
                    channel = player_text_channels[guild_id]
                    minutes, seconds = divmod(next_track.length // 1000, 60)
                    duration = f"{minutes}:{seconds:02d}"
                    await channel.send(
                        f"> 🎵 **Now Playing:** `{next_track.title}`\n"
                        f"> 🎤 **Artist:** `{next_track.author}`\n"
                        f"> ⏳ **Duration:** `{duration}`"
                    )
            except:
                pass
            
            print(f"\033[92m[QUEUE]\033[0m ⏭️ {next_track.title}")
        except Exception as e:
            print(f"\033[91m[ERROR]\033[0m Failed to play next track: {e}")
        return  # CRITICAL: Return here to prevent autoplay when queue has songs
    
    # AUTOPLAY: Only if enabled AND queue is empty
    if autoplay_mode.get(guild_id, False):
        try:
            if payload.track:
                # Get played tracks history
                if guild_id not in played_tracks:
                    played_tracks[guild_id] = []
                
                # Search for different songs
                search_queries = [
                    f"top songs {datetime.now().year}",
                    f"trending music",
                    f"popular songs",
                ]
                
                # Try to find unique track
                for search_query in search_queries:
                    tracks = await wavelink.Playable.search(f"ytsearch:{search_query}")
                    
                    if tracks:
                        for track in tracks[:15]:
                            track_id = f"{track.author}-{track.title}"
                            if track_id not in played_tracks[guild_id]:
                                await player.play(track)
                                played_tracks[guild_id].append(track_id)
                                
                                if len(played_tracks[guild_id]) > 30:
                                    played_tracks[guild_id].pop(0)
                                
                                print(f"\033[96m[AUTOPLAY]\033[0m 🎶 {track.title}")
                                
                                # Send autoplay message
                                try:
                                    if guild_id in player_text_channels:
                                        channel = player_text_channels[guild_id]
                                        await channel.send(f"> 🎶 **Autoplay:** `{track.title}` by `{track.author}`")
                                except:
                                    pass
                                
                                return
                
                # Clear history if nothing found
                played_tracks[guild_id] = []
                print(f"\033[93m[AUTOPLAY]\033[0m Queue empty, playback stopped")
        except Exception as e:
            print(f"\033[91m[ERROR]\033[0m Autoplay failed: {e}")
    else:
        print(f"\033[93m[MUSIC]\033[0m Queue empty, playback stopped")

async def send(ctx, message: str, delete_after: int = None):
    msg = await ctx.send(f"{message}")  # Changed from ctx.reply to ctx.send
    try:
        await delete_message(ctx.message.id, ctx.channel.id)
    except:
        pass
    return msg

def is_owner(ctx):
    return ctx.author.id in OWNER_ID

def get_volume(guild_id):
    """Get custom volume for guild, default 1000"""
    return guild_volumes.get(guild_id, 1000)

def set_guild_volume(guild_id, volume):
    """Set persistent volume for guild"""
    guild_volumes[guild_id] = volume
    print(f"[MUSIC] Guild {guild_id} volume set to {volume}%")

def delete_message(msg_id, channel_id):
    with open('config.json', 'r') as config_file:
        config = json.load(config_file)
    token = config.get("token")
    url = f"https://discord.com/api/v9/channels/{channel_id}/messages/{msg_id}"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    response = requests.delete(url, headers=headers)

@bot.command()
async def join(ctx: commands.Context, channel: discord.VoiceChannel = None):
    if not is_owner(ctx):
        return

    if channel:
        if not isinstance(channel, discord.VoiceChannel):
            return await send(ctx, ":x: **The provided channel ID is not a valid voice channel.** ")
    else:
        if ctx.author.voice and ctx.author.voice.channel:
            channel = ctx.author.voice.channel
        else:
            return await send(ctx, ":x: **You must join a voice channel before using this command.** ")
    
    player = ctx.voice_client
    if not player:
        try:
            player = await channel.connect(cls=wavelink.Player)
            # Apply guild's custom volume
            guild_vol = get_volume(ctx.guild.id)
            await player.set_volume(guild_vol)
            await send(ctx, f":white_check_mark: **Joined `{channel.name}` successfully.** Volume: {guild_vol}%")
        except discord.ClientException:
            await send(ctx, ":x: **I couldn't join the voice channel. Please try again.** ")
    else:
        await send(ctx, ":warning: **I'm already connected to a voice channel.** ")

@bot.command()
async def play(ctx: commands.Context, *, query: str) -> None:
    if not is_owner(ctx):
        return
    if not ctx.guild:
        return
    
    # Store channel for now playing messages
    player_text_channels[ctx.guild.id] = ctx.channel
    
    player = ctx.voice_client
    
    # Connect to voice if needed
    if not player or not player.connected:
        try:
            if player:
                try:
                    await player.disconnect()
                except:
                    pass
                await asyncio.sleep(0.5)
            
            if not ctx.author.voice or not ctx.author.voice.channel:
                await ctx.send("> ❌ **You must be in a voice channel to use this command.**")
                await delete_message(ctx.message.id, ctx.channel.id)
                return
            
            player = await ctx.author.voice.channel.connect(cls=wavelink.Player)
            # Apply guild's custom volume
            guild_vol = get_volume(ctx.guild.id)
            await player.set_volume(guild_vol)
            print(f"\033[94m[CONNECT]\033[0m 🔊 {ctx.author.voice.channel.name} | Volume: {guild_vol}%")
        except Exception as e:
            await ctx.send(f"> ❌ **Failed to join voice channel:** `{e}`")
            await delete_message(ctx.message.id, ctx.channel.id)
            return
    
    # Search for tracks with better accuracy
    try:
        tracks = await wavelink.Playable.search(f"ytsearch:{query}")
        if not tracks:
            tracks = await wavelink.Playable.search(query)
    except Exception as e:
        await ctx.send(f"> ❌ **Search failed:** `{e}`")
        await delete_message(ctx.message.id, ctx.channel.id)
        return
    
    if not tracks:
        await ctx.send(f"> ⚠️ **No tracks found for:** `{query}`")
        await delete_message(ctx.message.id, ctx.channel.id)
        return
    
    # Handle playlist
    if isinstance(tracks, wavelink.Playlist):
        added = 0
        for track in tracks.tracks:
            await player.queue.put_wait(track)
            added += 1
        
        msg = await ctx.send(f"> ✅ **Playlist Added:** `{tracks.name}` *({added} tracks)* 🎵")
        await delete_message(ctx.message.id, ctx.channel.id)
        print(f"\033[95m[PLAYLIST]\033[0m 📀 {tracks.name} ({added} tracks)")
        
        # Start playing first track if not playing
        if not player.playing and not player.paused:
            try:
                first_track = await player.queue.get_wait()
                await player.play(first_track)
                print(f"\033[92m[PLAYING]\033[0m 🎵 {first_track.title}")
            except Exception as e:
                print(f"\033[91m[ERROR]\033[0m {e}")
    else:
        # Single track
        track = tracks[0]
        minutes, seconds = divmod(track.length // 1000, 60)
        duration = f"{minutes}:{seconds:02d}"
        
        # If already playing, add to queue
        if player.playing or player.paused:
            await player.queue.put_wait(track)
            msg = await ctx.send(
                f"> 🎵 **Track Added to Queue:** `{track.title}`\n"
                f"> 🎤 **Artist:** `{track.author}`\n"
                f"> ⏳ **Duration:** `{duration}`\n"
                f"> 📊 **Queue Position:** `#{player.queue.count}`"
            )
            await delete_message(ctx.message.id, ctx.channel.id)
            print(f"\033[93m[QUEUE]\033[0m ➕ {track.title} (Position: #{player.queue.count})")
        else:
            # Play immediately
            try:
                await player.play(track)
                msg = await ctx.send(
                    f"> 🎵 **Now Playing:** `{track.title}`\n"
                    f"> 🎤 **Artist:** `{track.author}`\n"
                    f"> ⏳ **Duration:** `{duration}`\n"
                    f"> 🔊 **Volume:** `{player.volume}%`"
                )
                await delete_message(ctx.message.id, ctx.channel.id)
                print(f"\033[92m[PLAYING]\033[0m 🎵 {track.title} | Vol: {player.volume}%")
            except Exception as e:
                print(f"\033[91m[ERROR]\033[0m {e}")

@bot.command()
async def queue(ctx: commands.Context):
    if not is_owner(ctx):
        return
    player = ctx.voice_client
    if not player or player.queue.is_empty:
        return await send(ctx, "> :x: **The queue is currently empty.**")
    queue_list = "\n".join([f"{i+1}. {track.title}" for i, track in enumerate(player.queue)])
    await send(ctx, f">>> 🎶 **Current Queue:**\n```{queue_list}```")

@bot.command()
async def clearqueue(ctx: commands.Context):
    if not is_owner(ctx):
        return

    player = ctx.voice_client
    if not player:
        return await send(ctx, "> :x: **No active player found.**")

    player.queue.clear()
    await send(ctx, "> :white_check_mark: **The song queue has been cleared successfully.**")

@bot.command()
async def tts(ctx, *, message: str):
    if not is_owner(ctx):
        return

    if not ctx.author.voice or not ctx.author.voice.channel:
        return await send(ctx, "> :x: **Please join a voice channel first.**")

    player: wavelink.Player = ctx.voice_client
    if not player or not player.connected:
        try:
            if player:
                await player.disconnect()
            player = await ctx.author.voice.channel.connect(cls=wavelink.Player)
            await player.set_volume(1000)  # Set volume only on new connection
        except discord.ClientException:
            return await send(ctx, "> :x: **I couldn't join the voice channel.**")

    msg = await send(ctx, "> :repeat: **Converting text to speech...**")

    api_url = f"https://api.kastg.xyz/api/ai/tts?input={message}&lang=English&voice=Emily"
    
    async with aiohttp.ClientSession() as session:
        async with session.get(api_url) as response:
            if response.status != 200:
                return await send(ctx, "> :x: **Failed to fetch TTS audio.**")
            data = await response.json()

    if not data.get("status") or "result" not in data or not data["result"]:
        return await send(ctx, "> :x: **Invalid response from TTS API.**")

    tts_url = data["result"][0]["url"]
    tracks = await wavelink.Playable.search(tts_url)
    if not tracks:
        return await send(ctx, "> :x: **Failed to load TTS audio.**")

    track = tracks[0] if isinstance(tracks, list) else tracks
    await player.play(track)
    await msg.edit(content=f":microphone2: **Speaking: `{message}`** | Volume: {player.volume}%")

@bot.command(aliases=['nxt', 'n'])
async def next(ctx: commands.Context) -> None:
    if not is_owner(ctx):
        return

    player = ctx.voice_client
    if not player:
        return
    
    if not player.queue.is_empty:
        next_track = await player.queue.get_wait()
        await player.play(next_track)
        msg = await send(ctx, "> :white_check_mark: **Skipped to the next track.**")
        await msg.reply(f"**:loud_sound: Now playing:** `{next_track.title}`")
    else:
        await player.stop()
        await send(ctx, "> :white_check_mark: **No more songs in the queue. Stopping playback.**")

@bot.command()
async def stop(ctx: commands.Context) -> None:
    if not is_owner(ctx):
        return

    player = ctx.voice_client
    if not player:
        return
    await player.stop()
    await send(ctx, "> :white_check_mark: **Playback stopped successfully.**")

@bot.command()
async def pause(ctx: commands.Context) -> None:
    if not is_owner(ctx):
        return

    player = ctx.voice_client
    if not player:
        return
    
    if not player.paused:
        await player.pause(True)
        await send(ctx, "> :white_check_mark: **Music paused successfully.**")
    else:
        await send(ctx, "> :warning: **Music is already paused.**")

@bot.command()
async def resume(ctx: commands.Context) -> None:
    if not is_owner(ctx):
        return

    player = ctx.voice_client
    if not player:
        return
    
    if player.paused:
        await player.pause(False)
        await send(ctx, "> :white_check_mark: **Music resumed successfully.**")
    else:
        await send(ctx, "> :warning: **Music is already playing.**")

@bot.command()
async def loop(ctx: commands.Context):
    if not is_owner(ctx):
        return

    player = ctx.voice_client
    if not player or not player.current:
        return await send(ctx, "> :x: **No song is currently playing.**")

    guild_id = ctx.guild.id
    loop_mode[guild_id] = not loop_mode.get(guild_id, False)

    if loop_mode[guild_id]:
        await send(ctx, f"> 🔁 **Looping ENABLED for `{player.current.title}`.**")
        print(f"[MUSIC] Loop mode enabled for guild {guild_id}")
    else:
        await send(ctx, f"> ⏹️ **Looping DISABLED for `{player.current.title}`.**")
        print(f"[MUSIC] Loop mode disabled for guild {guild_id}")

@bot.command(aliases=["shuf"])
async def shuffle(ctx):
    if not is_owner(ctx):
        return

    player = ctx.voice_client
    if not player or player.queue.is_empty:
        return await send(ctx, "> Not enough tracks to shuffle.")
    
    # Convert queue to list, shuffle, and rebuild
    tracks = list(player.queue)
    if len(tracks) > 1:
        random.shuffle(tracks)
        player.queue.clear()
        for track in tracks:
            await player.queue.put_wait(track)
        await send(ctx, "> ✅ Queue has been shuffled.")
    else:
        await send(ctx, "> Not enough tracks to shuffle.")

@bot.command(aliases=['np', 'nowp'])
async def nowplaying(ctx):
    if not is_owner(ctx):
        return

    player = ctx.voice_client
    if not player or not player.current:
        await send(ctx, "> No track is currently playing.")
        return
    track = player.current
    await send(ctx, f"> :loud_sound: **Now playing:** `{track.title}`")

@bot.command(aliases=["vol", "setvol"])
async def volume(ctx, volume: int = None):
    if not is_owner(ctx):
        return

    player = ctx.voice_client
    if not player:
        await send(ctx, "> :x: I am not connected to a voice channel.")
        return

    if volume is None:
        current_volume = get_volume(ctx.guild.id)
        await send(ctx, f":loud_sound: **Current default volume: {current_volume}%**")
    else:
        if 0 <= volume <= 10000:
            # Set guild volume (persistent)
            set_guild_volume(ctx.guild.id, volume)
            await player.set_volume(volume)
            
            if volume > 1000:
                await send(ctx, f":loud_sound: **⚠️ DEFAULT VOLUME SET: {volume}%** (All future songs will use this)")
            else:
                await send(ctx, f":loud_sound: **DEFAULT VOLUME SET: {volume}%** (Persistent for all songs)")
        else:
            await send(ctx, "> Please provide a valid volume between 0 and 10000.")

@bot.command(aliases=["dc", "leave"])
async def disconnect(ctx: commands.Context) -> None:
    if not is_owner(ctx):
        return

    player = ctx.voice_client
    if not player:
        return
    await player.disconnect()
    await send(ctx, "> :white_check_mark: **Disconnected from the voice channel.**")

@bot.command()
async def status(ctx):
    """Check player status"""
    if not is_owner(ctx):
        return
    
    player = ctx.voice_client
    if not player:
        return await send(ctx, "> ❌ **Not connected to voice channel**")
    
    status_msg = f"""
> **🎵 Player Status:**
> Connected: `{player.connected}`
> Playing: `{player.playing}`
> Paused: `{player.paused}`
> Queue Size: `{player.queue.count}`
> Volume: `{player.volume}%`
> Current Track: `{player.current.title if player.current else 'None'}`
    """
    await send(ctx, status_msg)

@bot.command()
async def forceplay(ctx):
    """Force start playback from queue"""
    if not is_owner(ctx):
        return
    
    player = ctx.voice_client
    
    # Reconnect if disconnected
    if not player or not player.connected:
        try:
            if player:
                await player.disconnect()
            player = await ctx.author.voice.channel.connect(cls=wavelink.Player)
            await player.set_volume(1000)  # Set volume only on new connection
            print(f"[DEBUG] Reconnected to voice channel")
        except:
            return await send(ctx, "> ❌ **Failed to connect to voice channel**")
    
    if player.queue.is_empty:
        return await send(ctx, "> ❌ **Queue is empty**")
    
    try:
        track = await player.queue.get_wait()
        await player.play(track)
        await send(ctx, f"> ✅ **Force playing:** `{track.title}` | Volume: {player.volume}%")
        print(f"[MUSIC] Force play: {track.title}")
    except Exception as e:
        await send(ctx, f"> ❌ **Error:** `{e}`")
        print(f"[ERROR] Force play failed: {e}")

@bot.command()
async def autoplay(ctx):
    """Toggle autoplay mode"""
    if not is_owner(ctx):
        return
    
    guild_id = ctx.guild.id
    autoplay_mode[guild_id] = not autoplay_mode.get(guild_id, False)
    
    if autoplay_mode[guild_id]:
        await send(ctx, "> 🎵 **AUTOPLAY ENABLED** - Bot will play related songs when queue ends")
        print(f"[MUSIC] Autoplay enabled for guild {guild_id}")
    else:
        await send(ctx, "> ⏹️ **AUTOPLAY DISABLED** - Bot will stop when queue ends")
        print(f"[MUSIC] Autoplay disabled for guild {guild_id}")

@bot.command()
async def reconnect(ctx):
    """Reconnect to voice channel (fixes 404 errors)"""
    if not is_owner(ctx):
        return
    
    player = ctx.voice_client
    
    try:
        if player:
            await player.disconnect()
            print("[DEBUG] Disconnected old player")
        
        await asyncio.sleep(1)
        
        if ctx.author.voice and ctx.author.voice.channel:
            player = await ctx.author.voice.channel.connect(cls=wavelink.Player)
            await player.set_volume(1000)  # Set volume on reconnect
            await send(ctx, "> ✅ **Reconnected successfully!**")
            print(f"[DEBUG] Reconnected to {ctx.author.voice.channel.name}")
        else:
            await send(ctx, "> ❌ **You must be in a voice channel**")
    except Exception as e:
        await send(ctx, f"> ❌ **Reconnection failed:** `{e}`")
        print(f"[ERROR] Reconnect failed: {e}")

@bot.command(aliases=['h', 'cmds', 'commands'])
async def help(ctx):
    """Display all music bot commands"""
    if not is_owner(ctx):
        return
    
    help_embed = """
╔═════════════════════════════════════════════════╗
║        🎵 MUSIC BOT COMMANDS - FULL LIST        ║
╚═════════════════════════════════════════════════╝

📀 **PLAYBACK CONTROLS**
`,play <song>` - Play/queue a song
`,pause` - Pause current track
`,resume` - Resume playback
`,stop` - Stop playback
`,skip [pos]` - Skip to next or position
`,clear` / `,reset` - Clear queue & stop

🔍 **SEARCH & DISCOVERY**
`,lookup <song>` - Preview top 5 results
`,nowplaying` / `,np` - Current track info

🔊 **VOLUME CONTROLS** (Persistent Forever)
`,volume` - Show current volume
`,volume <0-10000>` - Set DEFAULT volume
`,raid [volume]` - Quick raid mode (5000%)

🎵 **QUEUE MANAGEMENT**
`,queue` - View queue
`,clearqueue` - Clear queue only
`,shuffle` - Shuffle queue
`,remove <pos>` - Remove song at position
`,move <from> <to>` - Move song position

⚙️ **SPECIAL FEATURES**
`,loop` - Toggle loop mode
`,autoplay` - Toggle smart autoplay
`,tts <text>` - Text-to-speech

👥 **ACCESS MANAGEMENT**
`,access @user` - Grant access
`,remove @user` - Revoke access (user management)
`,accesslist` - Show all users

🔧 **BOT MANAGEMENT**
`,join [channel]` - Join VC
`,leave` / `,dc` - Leave VC
`,reconnect` - Fix errors
`,status` - Player status
`,stats` / `,info` - Bot statistics
`,help` - This menu

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚡ **EXAMPLES:**
`,skip` - Skip to next song
`,skip 5` - Skip to song #5 in queue
`,volume 50` - All songs play at 50% (forever)
`,remove 3` - Remove song at position 3
`,move 5 1` - Move song from #5 to #1
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    """
    
    await send(ctx, f"```{help_embed}```")
    print(f"\033[96m[HELP]\033[0m 📋 Help menu displayed")

@bot.command()
async def raid(ctx, volume: int = 5000):
    """Set extreme volume for raids (Educational purpose only)"""
    if not is_owner(ctx):
        return
    
    player = ctx.voice_client
    if not player:
        return await send(ctx, "> ❌ **Not connected to voice channel**")
    
    if volume < 1000:
        volume = 5000
    elif volume > 10000:
        volume = 10000
    
    # Set as persistent guild volume
    set_guild_volume(ctx.guild.id, volume)
    await player.set_volume(volume)
    await send(ctx, f"```diff\n+ RAID MODE ACTIVATED\n+ Volume: {volume}%\n+ ⚠️ WARNING: EXTREME AUDIO LEVELS\n+ Now set as DEFAULT for all songs\n+ Educational Purpose Only```")
    print(f"[MUSIC] RAID MODE: Volume set to {volume}%")

@bot.command(aliases=['grant', 'adduser'])
async def access(ctx, user: discord.User = None):
    """Grant access to a user to control the music bot"""
    # Only current owners can grant access
    if ctx.author.id not in OWNER_ID:
        return await send(ctx, "> ❌ **You don't have permission to grant access**")
    
    if user is None:
        return await send(ctx, "> ⚠️ **Usage:** `,access @user` or `,access user_id`")
    
    if user.id in OWNER_ID:
        return await send(ctx, f"> ⚠️ **{user.name} already has access!**")
    
    # Add user to allowed list
    OWNER_ID.append(user.id)
    
    # Save to config
    try:
        config['allowed_users'] = OWNER_ID
        with open('music_config.json', 'w') as f:
            json.dump(config, f, indent=2)
        
        await send(ctx, f"> ✅ **Access granted to {user.name}!**\n> They can now use all music commands.")
        print(f"[ACCESS] Granted access to {user.name} ({user.id})")
    except Exception as e:
        await send(ctx, f"> ❌ **Failed to save:** `{e}`")

@bot.command(aliases=['revoke', 'removeuser'])
async def remove(ctx, user: discord.User = None):
    """Remove access from a user"""
    if ctx.author.id not in OWNER_ID:
        return await send(ctx, "> ❌ **You don't have permission to remove access**")
    
    if user is None:
        return await send(ctx, "> ⚠️ **Usage:** `,remove @user` or `,remove user_id`")
    
    if user.id not in OWNER_ID:
        return await send(ctx, f"> ⚠️ **{user.name} doesn't have access!**")
    
    # Remove user
    OWNER_ID.remove(user.id)
    
    # Save to config
    try:
        config['allowed_users'] = OWNER_ID
        with open('music_config.json', 'w') as f:
            json.dump(config, f, indent=2)
        
        await send(ctx, f"> ✅ **Access removed from {user.name}!**")
        print(f"[ACCESS] Removed access from {user.name} ({user.id})")
    except Exception as e:
        await send(ctx, f"> ❌ **Failed to save:** `{e}`")

@bot.command(aliases=['users', 'allowed'])
async def accesslist(ctx):
    """Show all users with access"""
    if not is_owner(ctx):
        return
    
    user_list = []
    for user_id in OWNER_ID:
        try:
            user = await bot.fetch_user(user_id)
            user_list.append(f"• {user.name} (`{user_id}`)")
        except:
            user_list.append(f"• Unknown User (`{user_id}`)")
    
    users_text = "\n".join(user_list) if user_list else "No users with access"
    await send(ctx, f"```\n📋 Users with Access:\n\n{users_text}\n```")

@bot.command(aliases=['search', 'find'])
async def lookup(ctx, *, query: str):
    """Search for songs and show top 5 results"""
    if not is_owner(ctx):
        return
    
    try:
        tracks = await wavelink.Playable.search(f"ytsearch:{query}")
        
        if not tracks:
            return await send(ctx, f"> ⚠️ **No results found for:** `{query}`")
        
        # Show top 5 results
        results = []
        for i, track in enumerate(tracks[:5], 1):
            minutes, seconds = divmod(track.length // 1000, 60)
            duration = f"{minutes}:{seconds:02d}"
            results.append(f"{i}. **{track.title}** by {track.author} [{duration}]")
        
        results_text = "\n".join(results)
        await send(ctx, f"```\n🔍 Search Results for '{query}':\n\n{results_text}\n\nUse ,play to add a song```")
        print(f"\033[96m[SEARCH]\033[0m 🔍 {query} - {len(tracks[:5])} results")
    except Exception as e:
        await send(ctx, f"> ❌ **Search failed:** `{e}`")

@bot.command(aliases=['clearall', 'reset'])
async def clear(ctx):
    """Clear queue and stop playback"""
    if not is_owner(ctx):
        return
    
    player = ctx.voice_client
    if not player:
        return await send(ctx, "> ❌ **Not connected to voice channel**")
    
    # Clear queue
    player.queue.clear()
    # Stop playback
    await player.stop()
    # Disable loop if active
    if ctx.guild.id in loop_mode:
        loop_mode[ctx.guild.id] = False
    
    await send(ctx, "> ✅ **Cleared queue and stopped playback!**")
    print(f"\033[93m[CLEAR]\033[0m 🗑️ Queue cleared and stopped")

@bot.command(aliases=['s'])
async def skip(ctx: commands.Context, position: int = None) -> None:
    """Skip to specific position in queue or next song"""
    if not is_owner(ctx):
        return

    player = ctx.voice_client
    if not player:
        return
    
    # Skip to specific position
    if position:
        if position < 1 or position > player.queue.count:
            return await send(ctx, f"> ❌ **Invalid position! Queue has {player.queue.count} songs.**")
        
        # Remove songs before the target
        for _ in range(position - 1):
            try:
                await player.queue.get_wait()
            except:
                break
        
        if not player.queue.is_empty:
            next_track = await player.queue.get_wait()
            await player.play(next_track)
            await send(ctx, f"> ⏭️ **Skipped to position {position}:** `{next_track.title}`")
            print(f"\033[92m[SKIP]\033[0m ⏭️ Position {position}: {next_track.title}")
        return
    
    # Skip to next song
    if not player.queue.is_empty:
        next_track = await player.queue.get_wait()
        await player.play(next_track)
        msg = await send(ctx, "> :white_check_mark: **Skipped to the next track.**")
        print(f"\033[92m[SKIP]\033[0m ⏭️ {next_track.title}")
    else:
        await player.stop()
        await send(ctx, "> :white_check_mark: **No more songs in the queue. Stopping playback.**")
        print(f"\033[93m[SKIP]\033[0m ⏹️ Queue empty, stopped")

@bot.command(aliases=['rm'])
async def removetrack(ctx, position: int):
    """Remove a song from queue by position"""
    if not is_owner(ctx):
        return
    
    player = ctx.voice_client
    if not player or player.queue.is_empty:
        return await send(ctx, "> ❌ **Queue is empty!**")
    
    if position < 1 or position > player.queue.count:
        return await send(ctx, f"> ❌ **Invalid position! Queue has {player.queue.count} songs.**")
    
    # Get queue as list
    queue_list = list(player.queue)
    removed_track = queue_list[position - 1]
    
    # Rebuild queue without the removed track
    player.queue.clear()
    for i, track in enumerate(queue_list):
        if i != position - 1:
            await player.queue.put_wait(track)
    
    await send(ctx, f"> ✅ **Removed from queue:** `{removed_track.title}`")
    print(f"\033[93m[REMOVE]\033[0m 🗑️ {removed_track.title}")

@bot.command(aliases=['move', 'mv'])
async def movetrack(ctx, from_pos: int, to_pos: int):
    """Move a song to different position in queue"""
    if not is_owner(ctx):
        return
    
    player = ctx.voice_client
    if not player or player.queue.is_empty:
        return await send(ctx, "> ❌ **Queue is empty!**")
    
    queue_size = player.queue.count
    if from_pos < 1 or from_pos > queue_size or to_pos < 1 or to_pos > queue_size:
        return await send(ctx, f"> ❌ **Invalid positions! Queue has {queue_size} songs.**")
    
    # Get queue as list
    queue_list = list(player.queue)
    moved_track = queue_list.pop(from_pos - 1)
    queue_list.insert(to_pos - 1, moved_track)
    
    # Rebuild queue
    player.queue.clear()
    for track in queue_list:
        await player.queue.put_wait(track)
    
    await send(ctx, f"> ✅ **Moved `{moved_track.title}` from position {from_pos} to {to_pos}**")
    print(f"\033[95m[MOVE]\033[0m 🔄 {moved_track.title} ({from_pos} → {to_pos})")

@bot.command(aliases=['info', 'botinfo'])
async def stats(ctx):
    """Show bot statistics"""
    if not is_owner(ctx):
        return
    
    player = ctx.voice_client
    uptime_seconds = int((datetime.now() - bot.start_time).total_seconds()) if hasattr(bot, 'start_time') else 0
    hours, remainder = divmod(uptime_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    stats_msg = f"""```
╔════════════════════════════════════╗
║        🎵 BOT STATISTICS 🎵        ║
╠════════════════════════════════════╣
║ Servers: {len(bot.guilds):<27} ║
║ Users with Access: {len(OWNER_ID):<16} ║
║ Connected: {('Yes' if player else 'No'):<24} ║
║ Playing: {('Yes' if player and player.playing else 'No'):<26} ║
║ Queue Size: {(player.queue.count if player else 0):<22} ║
║ Default Volume: {get_volume(ctx.guild.id):<18} ║
║ Autoplay: {('ON' if autoplay_mode.get(ctx.guild.id, False) else 'OFF'):<25} ║
║ Loop: {('ON' if loop_mode.get(ctx.guild.id, False) else 'OFF'):<29} ║
║ Uptime: {hours}h {minutes}m {seconds}s{' ' * (21 - len(f'{hours}h {minutes}m {seconds}s'))} ║
╚════════════════════════════════════╝
```"""
    
    await send(ctx, stats_msg)
    print(f"\033[96m[STATS]\033[0m 📊 Displayed bot statistics")

async def main():
    try:
        await bot.start(music_token)
    except discord.errors.LoginFailure:
        ascii = f"""[-]================================] | [ Invalid token ] | [================================[-]"""
        print(Colorate.Horizontal(Colors.blue_to_cyan, Center.XCenter(ascii)))

if __name__ == "__main__":
    asyncio.run(main())